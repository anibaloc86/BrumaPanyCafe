declare module '@lucide/astro';
